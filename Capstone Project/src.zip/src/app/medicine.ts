export class Medicine{

    id?:any;
    medName?:String;
    quantity?:String;
    price?:String;
    active?: boolean ;

}